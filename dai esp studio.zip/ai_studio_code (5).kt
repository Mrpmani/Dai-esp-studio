package com.example.daiespstudio.data.local

import androidx.room.*
import com.example.daiespstudio.data.model.Library
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM libraries WHERE name LIKE '%' || :query || '%' OR author LIKE '%' || :query || '%'")
    fun searchLibraries(query: String): Flow<List<Library>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLibraries(libraries: List<Library>)

    @Query("UPDATE libraries SET isInstalled = :installed WHERE name = :libraryName")
    suspend fun updateInstallationStatus(libraryName: String, installed: Boolean)

    @Query("DELETE FROM libraries")
    suspend fun clearLibraries()
}

@Database(entities = [Library::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao
}