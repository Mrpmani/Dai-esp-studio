package com.example.daiespstudio.ui.sketches

import androidx.lifecycle.ViewModel
import com.example.daiespstudio.data.model.Sketch
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class SketchesViewModel @Inject constructor() : ViewModel() {

    private val _selectedSketch = MutableStateFlow<Sketch?>(null)
    val selectedSketch: StateFlow<Sketch?> = _selectedSketch.asStateFlow()

    val mockSketches = listOf(