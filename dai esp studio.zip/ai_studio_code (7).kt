package com.example.daiespstudio.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.daiespstudio.data.local.LibraryDao
import com.example.daiespstudio.data.model.Board
import com.example.daiespstudio.data.model.Library
import com.example.daiespstudio.data.remote.ArduinoLibraryApi
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject

private val Context.dataStore by preferencesDataStore("settings")

class EspRepository @Inject constructor(
    private val libraryDao: LibraryDao,
    private val libraryApi: ArduinoLibraryApi,
    @ApplicationContext private val context: Context
) {

    // --- Boards Mock Data ---
    fun getBoards(): List<Board> = listOf(
        Board("esp32", "ESP32 Dev Module", "Generic ESP32 board", "https://random-image-url.com/esp32.png"),
        Board("esp8266", "NodeMCU 1.0", "ESP8266 widely used board", "https://random-image-url.com/nodemcu.png"),
        Board("uno", "Arduino Uno", "Classic AVR board", "https://random-image-url.com/arduino.png")
    )

    // --- Last Board Prefs ---
    private val LAST_BOARD_KEY = stringPreferencesKey("last_board_id")

    suspend fun saveLastBoard(boardId: String) {
        context.dataStore.edit { preferences ->
            preferences[LAST_BOARD_KEY] = boardId
        }
    }

    suspend fun getLastBoard(): String? {
        return context.dataStore.data.map { preferences ->
            preferences[LAST_BOARD_KEY]
        }.first()
    }

    // --- Library Store with Caching ---
    fun searchLibrariesLocal(query: String): Flow<List<Library>> {
        return libraryDao.searchLibraries(query)
    }

    suspend fun refreshLibraries() {
        try {
            val response = libraryApi.getLibraryIndex()
            // Assume success, clear old, insert new
            val remoteLibs = response.libraries
            // Before inserting, check what is currently installed to preserve state
            // For simplicity in this example, we just refresh and lose state, 
            // production app should merge data carefully.
            libraryDao.clearLibraries()
            libraryDao.insertLibraries(remoteLibs)
        } catch (e: Exception) {
            // Handle offline mode: if API fails, we just rely on existing DB
        }
    }

    suspend fun toggleInstallation(libraryName: String, currentStatus: Boolean) {
        libraryDao.updateInstallationStatus(libraryName, !currentStatus)
    }
}