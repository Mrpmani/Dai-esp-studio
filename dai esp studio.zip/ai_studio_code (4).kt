package com.example.daiespstudio.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

// --- Boards ---
data class Board(
    val id: String,
    val name: String,
    val details: String,
    val iconUrl: String // URL to asset or local res constant
)

// --- Library Store ---
data class LibraryIndex(
    val libraries: List<Library>
)

@Entity(tableName = "libraries")
data class Library(
    @PrimaryKey val name: String, // Used as unique ID for simplicity
    val author: String,
    val version: String,
    var isInstalled: Boolean = false // Local flag
)

// --- Sketches ---
data class Sketch(val id: Int, val name: String, val code: String)