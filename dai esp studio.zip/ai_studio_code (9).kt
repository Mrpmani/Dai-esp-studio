package com.example.daiespstudio.ui.boards

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.daiespstudio.data.model.Board
import com.example.daiespstudio.data.repository.EspRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BoardsViewModel @Inject constructor(
    private val repository: EspRepository
) : ViewModel() {

    private val _boards = MutableStateFlow<List<Board>>(emptyList())
    val boards: StateFlow<List<Board>> = _boards.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _lastSelectedBoard = MutableStateFlow<Board?>(null)
    val lastSelectedBoard: StateFlow<Board?> = _lastSelectedBoard.asStateFlow()

    private var allBoards = listOf<Board>()

    init {
        loadBoards()
        loadLastBoard()
    }

    private fun loadBoards() {
        allBoards = repository.getBoards()
        _boards.value = allBoards
    }

    private fun loadLastBoard() {
        viewModelScope.launch {
            val id = repository.getLastBoard()
            _lastSelectedBoard.value = allBoards.find { it.id == id }
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _boards.value = allBoards
        } else {
            _boards.value = allBoards.filter {
                it.name.contains(query, ignoreCase = true)
            }
        }
    }

    fun selectBoard(board: Board) {
        _lastSelectedBoard.value = board
        viewModelScope.launch {
            repository.saveLastBoard(board.id)
        }
    }
}