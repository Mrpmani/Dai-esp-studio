package com.example.daiespstudio.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryOrange = Color(0xFFFF6B00)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1D1D1D)
val TextPrimary = Color(0xFFE0E0E0)
val TextSecondary = Color(0xFFB0B0B0)