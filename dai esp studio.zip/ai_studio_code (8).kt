package com.example.daiespstudio.di

import android.content.Context
import androidx.room.Room
import com.example.daiespstudio.data.local.AppDatabase
import com.example.daiespstudio.data.local.LibraryDao
import com.example.daiespstudio.data.remote.ArduinoLibraryApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideRetrofit(): ArduinoLibraryApi {
        return Retrofit.Builder()
            .baseUrl("https://downloads.arduino.cc/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ArduinoLibraryApi::class.java)
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "esp_studio_db"
        ).build()
    }

    @Provides
    fun provideLibraryDao(database: AppDatabase): LibraryDao {
        return database.libraryDao()
    }
}