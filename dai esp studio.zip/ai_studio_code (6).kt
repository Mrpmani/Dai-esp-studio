package com.example.daiespstudio.data.remote

import com.example.daiespstudio.data.model.LibraryIndex
import retrofit2.http.GET

interface ArduinoLibraryApi {
    @GET("libraries/library_index.json")
    suspend fun getLibraryIndex(): LibraryIndex
}